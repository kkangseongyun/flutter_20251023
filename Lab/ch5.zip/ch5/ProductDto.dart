class ProductDto {
  final String image;
  final String title;
  final String description;

  ProductDto(this.image, this.title, this.description);
}